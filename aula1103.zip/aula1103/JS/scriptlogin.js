function check(){

let usuariocheck = document.getElementById("usuario")
let senhacheck = document.getElementById("senha")
let ifcheck = 0

for(let i = 0; i < listadeusuarios.length; i++){
    if(listadeusuarios[i].usuario == usuariocheck && listadeusuarios[i].senha == senhacheck){
       alert("Usuário e senhas corretos!")
       ifcheck = 1
    }
    
}

if(ifcheck == 0){
    alert("Usuário ou senha errados.")
}
}