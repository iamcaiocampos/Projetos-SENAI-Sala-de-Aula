let listadeusuarios = []

function enviar(){

let usuario = document.getElementById("usuario").value
let email = document.getElementById("email").value
let idade = document.getElementById("idade").value
let telefone = document.getElementById("telefone").value
let senha = document.getElementById("senha").value
let confirmarsenha = document.getElementById("senha2").value

if(senha == confirmarsenha){
alert("Usuário cadastrado")


listadeusuarios.push({
    usuario: usuario, 
    email: email, 
    idade: idade, 
    telefone: telefone,
    senha: senha});
}
else{
    alert("as senhas estão diferentes!")
    
}}




