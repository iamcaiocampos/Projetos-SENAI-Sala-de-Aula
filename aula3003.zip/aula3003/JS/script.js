async function Pesquisar(){
    let display = document.getElementById("display")
    let pais = document.getElementById("pais").value
    let estado = document.getElementById("estado").value
    let cidade = document.getElementById("cidade").value
    let apikey = "e792fa40e76dcfef0c2041b3b82cd124"
    let units = "metric"
    let limit = 5

    try{
        let response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cidade},${estado},${pais}&units=${units}&lang=pt&appid=${apikey}`)

    let dados = await response.json()

    let temperatura = dados.main.temp
    let lat = dados.coord.lat
    let lon = dados.coord.lon
    let descricao = dados.weather[0].description

    console.log(temperatura)
    console.log(lat)
    console.log(lon)
    console.log(descricao)

    console.log(dados)

    display.innerHTML = `<br><p>Temperatura: ${temperatura} <br><br>
                         Descrição: ${descricao} <br><br>
                         Latitude: ${lat}<br><br>
                         Longitude: ${lon}<br></p>`

    } catch(error){
        alert ("Algum erro aconteceu ou a sua cidade não existe")
        display.innerHTML = `ERROR`
    }


    


    
}