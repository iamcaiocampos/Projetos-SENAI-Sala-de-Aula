async function Pesquisar(){
    let display = document.getElementById("display")
    let pais = document.getElementById("pais").value
    let estado = document.getElementById("estado").value
    let cidade = document.getElementById("cidade").value
    let apikey = "e792fa40e76dcfef0c2041b3b82cd124"
    let units = "metric"
    let limit = 5

    let response = await fetch(`http://api.openweathermap.org/geo/1.0/direct?q=${cidade},${estado},${pais}&limit=${limit}&appid=${apikey}`)

    let dados = await response.json()

    let lat = dados[0].lat

    let lon = dados[0].lon

    console.log(lat)

    console.log(lon)


    let response2 = await fetch(`https://api.openweathermap.org/data/3.0/onecall?lat=${lat}&lon=${lon}&units=${units}&appid=${apikey}`)

    let dados2 = await response2.json()

    let temperatura = dados2.temperature.degrees
    let unit = 

    console.log(dados2)

    display.innerHTML = ""


    
}