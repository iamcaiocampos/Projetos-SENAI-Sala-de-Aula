let velocidade;

//criando função
function funcao(){
   //user input dos valores   
    velocidade = Number(prompt("Coloque a sua velocidade: "));
    
//lógica
if (velocidade <= 80 && velocidade >0){
    alert("Você não recebeu multa.")
}
else if (velocidade > 80 && velocidade <= 100){
    alert("Você recebeu uma multa leve no valor de 150R$")
}
else if (velocidade > 100 && velocidade <= 120){
    alert("Você recebeu uma multa grave no valor de 300R$")
}

else if (velocidade > 120){
    alert("Você recebeu uma multa gravíssima no valor de 600R$")
} else{
    alert("Velocidade inválida.")
}

//chamando a função
}
funcao();    