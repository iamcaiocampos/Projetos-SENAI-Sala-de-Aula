// definindo variaveis
let num1;
let num2;
let operador;
let resultado;
//criando função
function funcao(){
   //user input dos valores   
    num1 = Number(prompt("coloque o primeiro numero: "));
    num2 = Number(prompt("coloque o segundo numero: "));
    operador = prompt("coloque o operador: (+,-,*,/)");
//lógica
if (operador == "+"){
    resultado = num1 + num2;
    alert("A soma entre os dois numeros é igual a " + resultado)
}

if (operador == "-"){
    resultado = num1 - num2;
    alert("A subtração entre os dois numeros é igual a " + resultado)
}

if (operador == "*"){
    resultado = num1 * num2;
    alert("A multiplicação entre os dois numeros é igual a " + resultado)
}
if (operador == "/"){
    resultado = num1 / num2;
    alert("A divisão entre os dois numeros é igual a " + resultado)
}

else if (operador != "+" && operador != "-" && operador != "*" && operador != "/") {
    alert("Operador inválido")
}
//chamando a função
}
funcao();    