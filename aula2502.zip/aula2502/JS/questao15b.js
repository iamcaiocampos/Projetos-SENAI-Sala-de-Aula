let numero;

//criando função
function funcao(){
   //user input dos valores   
    numero = Number(prompt("Coloque o número: "));
    
//lógica
if (numero > 0 && numero < 100 ){
    alert("O seu número está dentro da faixa.")
} else{
    alert("O seu número não está dentro da faixa.")
}

//chamando a função
}
funcao();    