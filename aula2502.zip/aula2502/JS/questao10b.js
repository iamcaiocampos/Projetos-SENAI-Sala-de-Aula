let valordacompra;

//criando função
function funcao(){
   //user input dos valores   
    valordacompra = Number(prompt("Coloque o valor da compra: "));
    
//lógica
if (valordacompra <= 100){
    alert("Você não teve desconto e a compra ficou no valor de " + valordacompra + "R$")
}
    else if (valordacompra > 100 && valordacompra <= 500){
        alert("Você teve um desconto de 10% e a compra ficou no valor de " + (valordacompra * 1.10) + "R$")
    }
 else if (valordacompra > 500){
    alert("Você teve um desconto de 20% e a compra ficou no valor de " + (valordacompra * 1.20) + "R$")
}

//chamando a função
}
funcao();    