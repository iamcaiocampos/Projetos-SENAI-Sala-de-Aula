let couf;
let numero;

function funcao(){
   couf = prompt("A sua temperatura é em celsius ou fahrenheit? coloque C ou F: ")
   numero = Number(prompt("Coloque a temperatura: "))

   if(couf == "F" || couf == "f"){
     alert("A sua temperatura de " + numero + "F é " + ((numero - 32) * 5/9))
   }
   else if(couf == "C" || couf == "c"){
    alert("A sua temperatura de " + numero + "C é " + ((numero * 9/5) + 32))
  }
}
funcao();