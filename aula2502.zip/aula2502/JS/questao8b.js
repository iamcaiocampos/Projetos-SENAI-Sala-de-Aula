// definindo variaveis
let ladoA;
let ladoB;
let ladoC;

//criando função
function funcao(){
   //user input dos valores   
    ladoA = Number(prompt("coloque o valor do primeiro lado: "));
    ladoB = Number(prompt("coloque o valor do segundo lado: "));
    ladoC = Number(prompt("coloque o valor do teceiro lado: "));
//lógica
    if(ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA){
 
        

           if(ladoA == ladoB && ladoB == ladoC){
            alert("O triângulo é equilátero")

          } else if(ladoA == ladoB && ladoB != ladoC || ladoA == ladoC && ladoC != ladoB){
            alert("O triângulo é isósceles")
          } else{
            alert("O triângulo é escaleno.")
          }
    } else {
        alert("Não é possível fazer um triângulo com esses valores")
    }
//chamando a função
}
funcao();    