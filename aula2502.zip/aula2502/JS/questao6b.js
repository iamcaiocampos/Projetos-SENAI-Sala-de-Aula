// definindo variaveis
let ano;
//criando função
function funcao(){
   //user input dos valores   
    ano = Number(prompt("coloque o ano: "));

//lógica
if(ano % 4 == 0 && ano % 100 != 0 || ano % 400 == 0){
    if(ano % 4 == 0 && ano % 100 != 0){
        alert("O ano é bissexto pois ele é divisivel por 4 e não é divisivel por 100.")
    } else if(ano % 400 == 0){
        alert("O ano é bissexto pois ele é divisivel por 400.")

    }

} 

else {
    alert("O ano não é bissexto")
}
//chamando a função
}
funcao();