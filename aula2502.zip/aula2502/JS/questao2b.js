

function imcvalor(){
    
    peso = Number(prompt("coloque o seu peso em kg: "));
altura = Number(prompt("coloque a sua altura em metro: "));

imc = peso/(altura*altura);
imc = imc.toFixed(2)
if(imc<=18.5) {
    alert("baixo peso");
} 
else if(imc> 18.5 && imc <25) {
    alert("o seu imc é: " + imc+ " seu status é peso normal.");
}else if(imc >= 25 && imc <30) {
    alert("o seu imc é: " + imc+ " seu status é sobrepeso.");
}
else if(imc >=30 && imc <35) {
    alert("o seu imc é: " + imc+ " seu status é obesidade grau I");
}

else if(imc >=35 && imc <40) {
    alert("o seu imc é: " + imc+ " seu status é obesidade grau II");
}

else if(imc > 40) {
    alert("o seu imc é: " + imc+ " seu status é obesidade grau III");
}

}
imcvalor();