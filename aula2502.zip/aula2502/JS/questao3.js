// definindo variaveis

let senha;
//criando função
function funcao(){
   //user input dos valores   
    senha = Number(prompt("coloque a sua senha: "));
//lógica
if(senha == 1234){
    alert("ACESSO PERMITIDO ")

} else{
    alert("ACESSO NEGADO")
}



//chamando a função
}
funcao  ();