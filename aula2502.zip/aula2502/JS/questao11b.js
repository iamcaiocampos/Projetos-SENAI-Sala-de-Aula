let numero;

//criando função
function funcao(){
   //user input dos valores   
    numero = Number(prompt("Coloque um número "));
    
//lógica
if (numero > 0){
    alert("número positivo")
} else if (numero < 0){
    alert("número negativo")
} else if (numero == 0){
    alert("número é zero")
}
if (numero % 2 == 0){
    alert("número par")
} else{
    alert ("número impar")
}

//chamando a função
}
funcao();    