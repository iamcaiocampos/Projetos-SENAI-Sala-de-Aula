let idade;

//criando função
function funcao(){
   //user input dos valores   
    idade = Number(prompt("Coloque sua idade: "));
    
//lógica

if (idade < 16 && idade > 0){
    alert("Você não pode votar.")
}
else if (idade >= 16 && idade <18){
    alert("o seu voto é facultativo")
} else if (idade >= 18 && idade <70){
    alert("o seu voto é obrigatório")
} else if (idade >=70){
    alert("o seu voto é facultativo")
}
 else{
    alert("idade inválida.")
 }
//chamando a função
}
funcao();    