let valordacompra;

//criando função
function funcao(){
   //user input dos valores   
    valordacompra = Number(prompt("Coloque o valor da compra: "));
    
//lógica
if (valordacompra <= 2000 && valordacompra > 0){
    alert("A sua comissão foi de 5%, que é " + (valordacompra * 0.05) + "R$")
}
if (valordacompra > 2000 && valordacompra <= 5000){
    alert("A sua comissão foi de 10%, que é " + (valordacompra * 0.10) + "R$")
}
if (valordacompra > 5000){
    alert("A sua comissão foi de 15%, que é " + (valordacompra * 0.15) + "R$")
}
if (valordacompra <= 0){
    alert("Compra inválida")
}
//chamando a função
}
funcao();    