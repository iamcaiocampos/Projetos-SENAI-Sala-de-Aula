// definindo variaveis
let idade;
//criando função
function funcao(){
   //user input dos valores   
    idade = Number(prompt("coloque a sua idade: "));

//lógica
if(idade >= 0 && idade < 13){
    alert("A sua catégoria é criança!")
   

} 

else if(idade >=13 && idade < 18){
    alert("A sua catégoria é adolescente")
   
} 
else if(idade >= 18 && idade < 59){
    alert("A sua catégoria é adulto")
   
} 
else if(idade >= 60){
    alert("A sua catégoria é idoso!")
   
} else if(idade < 0) {
    alert("Idade inválida.")
}
//chamando a função
}
funcao();