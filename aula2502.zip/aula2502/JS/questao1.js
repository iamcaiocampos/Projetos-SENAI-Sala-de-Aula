// definindo variaveis

let valor1;
let valor2;
//criando função
function funcao(){
   //user input dos valores   
    valor1 = Number(prompt("coloque o primeiro número: "));
valor2 = Number(prompt("coloque o segundo número: "));

//lógica
if(valor1 == valor2){
    alert("Os valores são iguais.")

}

else {
    alert("Os valores são diferentes.")
    
}


//chamando a função
}
funcao();