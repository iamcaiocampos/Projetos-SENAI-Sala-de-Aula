// definindo variaveis
let porsalario;
let salario;
let parcela;
//criando função
function funcao(){
   //user input dos valores   
    salario = Number(prompt("coloque o seu salário: "));
    parcela = Number(prompt("Qual o valor da parcela? "))
    porsalario = salario * 0.30;
//lógica
if(parcela <= salario){
    alert("Empréstimo aprovado!")
    alert("Valor máximo de empréstimo para seu salário: " +porsalario)

} else{
    alert("Empréstimo negado.")
    alert("Valor máximo de empréstimo para seu salário: " +porsalario)
}

//chamando a função
}
funcao();