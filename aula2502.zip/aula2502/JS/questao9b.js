// definindo variaveis
let username;
let password;
let operador;
let resultado;
//criando função
function funcao(){
   //user input dos valores   
    username = prompt("Coloque o seu nome: ");
    password = prompt("coloque a sua senha: : ");
    
//lógica
if (username == "admin" && password == "1234"){
    alert("Usuário e senha corretos, você está autorizado.")
} else if (username == "admin" && password != "1234"){
    alert("Senha errada, tente novamente.")
} else if (username != "admin" && password != "1234"){
    alert("Usuário e Senha errados, tente novamente.")
}

//chamando a função
}
funcao();    