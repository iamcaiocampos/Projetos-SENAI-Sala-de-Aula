// definindo variaveis

let valor1;
let valor2;
//criando função
function funcao(){
   //user input dos valores   
    valor1 = Number(prompt("coloque o primeiro número: "));
valor2 = Number(prompt("coloque o segundo número: "));

//lógica
if(valor1 > valor2){
    alert("o valor 1: " +valor1+ " é maior que o valor 2: " + valor2 )

}

if(valor2 > valor1){
    alert("o valor 2: " +valor2+ " é maior que o valor 1: " + valor1 )

}


//chamando a função
}
funcao();