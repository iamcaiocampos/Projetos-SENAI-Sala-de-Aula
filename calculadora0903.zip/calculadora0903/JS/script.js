
function Calculo(){
let num1 = document.getElementById("num1").value;
let num2 = document.getElementById("num2").value;
let operador = document.getElementById("operador").value;

num1 = parseFloat(num1)
num2 = parseFloat(num2)


if (operador == "+"){
     document.getElementById("resultado").innerHTML =
        "O resultado é: " + (num1 + num2);
}

if (operador == "-"){
    document.getElementById("resultado").innerHTML =
        "O resultado é: " + (num1 - num2);
}

if (operador == "*"){
    document.getElementById("resultado").innerHTML =
        "O resultado é: " + (num1 * num2);
}
if (operador == "/"){
    document.getElementById("resultado").innerHTML =
        "O resultado é: " + (num1 / num2);
}

else if (operador != "+" && operador != "-" && operador != "*" && operador != "/") {
    document.getElementById("resultado").innerHTML =
        "O operador é inválido.";
}
}