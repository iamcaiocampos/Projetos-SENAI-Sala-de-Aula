function TocarAudio(elemento) {
    const player = document.getElementById("player")
    let tempsrc = elemento.getAttribute("data-src")

    if (player.src.includes(tempsrc.replace("../", ""))) {
        if (player.paused) {
            player.play()
            elemento.classList.add("tocando")
        } 
        else {
            player.pause()
            elemento.classList.remove("tocando")
        }
    } 
    
    else{
        document.querySelectorAll("li.tocando").forEach(function(li){ 
            li.classList.remove("tocando")})
        
        player.src = tempsrc
        player.play()   
        elemento.classList.add("tocando")
    }
   
}