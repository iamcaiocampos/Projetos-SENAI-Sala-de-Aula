the audio folder is too big for GitHub, so the data-src is blank, add your own audio files if you wish to test this code add your own files.

a pasta de audio está muito pesada pro GitHub, então o data-src está sem nada, coloque os seus próprios arquivos de áudio se você deseja testar esse código.