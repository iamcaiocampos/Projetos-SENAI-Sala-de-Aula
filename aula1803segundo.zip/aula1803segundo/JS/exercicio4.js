function exercicio4(){
    const container = document.getElementById("container")

    const card = document.createElement('div')
    card.className = "container_card"

    const div0 = document.createElement('div')
    card.id = "idTexto"
    card.className = "texto"

    const paragrafo = document.createElement('p')
    paragrafo.className = "TextoImagem"
    paragrafo.textContent = "Esta imagem em alta-resolução, captada pelo telescópio espacial Hubble, e conhecida como Hubble Ultra Deep Field, mostra uma grande variedade de galáxias, cada uma composta de bilhões de estrelas. As pequenas galáxias avermelhadas, aproximadamente 100, são algumas  das galáxias  mais distantes fotografados  por um telescópio óptico."

    const div1 = document.createElement('div')
    div1.className = "container_imagem"

    const img = document.createElement('img')
    img.src ="../images/img01.jpeg"

    container.appendChild(card)
    card.appendChild(div0)
    div0.appendChild(paragrafo)
    card.appendChild(div1)
    div1.appendChild(img)




}

exercicio4()