function exercicio1(){
    const container = document.getElementById("container")
    container.className = "container"

    const titulo = document.createElement('h1')
    titulo.textContent = "Minha Página"

    container.appendChild(titulo)

    const div0 = document.createElement('div')

    const titulo2 = document.createElement('h2')
    titulo.textContent = "Lista de tarefas"

    const lista = document.createElement('ul')

    const item1 = document.createElement('li');
    item1.textContent = "Estudar Javascript";

    const item2 = document.createElement('li');
    item2.textContent = "Praticar createElement";
    
    const item3 = document.createElement('li');
    item3.textContent = "Fazer exercícios";

    div0.appendChild(titulo2)
    lista.appendChild(item1)
    lista.appendChild(item2)
    lista.appendChild(item3)
    div0.appendChild(lista)
    container.appendChild(div0)

    const div1 = document.createElement('div')

    const titulo3 = document.createElement('h2')
    titulo3.textContent = "Contato"

    const email = document.createElement('p')
    email.textContent = "aluno@gmail.com"
    
    div1.appendChild(titulo3)
    div1.appendChild(email)
    container.appendChild(div1)


}

exercicio1()