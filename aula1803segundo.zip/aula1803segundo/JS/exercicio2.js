function exercicio2(){
 const container = document.getElementById("container")
 container.className = "container"

 const form = document.createElement('form')

 const titulo = document.createElement('h2')
 titulo.textContent = "Cadastro"
  
 const div0 = document.createElement('div')

 const label0 = document.createElement('label')
 label0.textContent = "Nome:"
 
 const input0 = document.createElement('input')
 input0.inputMode = "text"
 input0.placeholder = "Digite seu nome:"

 const div1 = document.createElement('div')

 const label1 = document.createElement('label')
 label1.textContent = "Email:"

 const input1 = document.createElement('input')

 input1.inputMode = "email"
 input1.placeholder = "Digite seu email:"

 const div2 = document.createElement('div')

const label2 = document.createElement('label')
 label2.textContent = "Senha:"

 const input2 = document.createElement('input')
 input2.inputMode = "password"
 input2.placeholder = "Digite sua senha:"

 const butao = document.createElement('button')
butao.textContent = "Cadastrar"

container.appendChild(form)
form.appendChild(titulo)
form.appendChild(div0)
div0.appendChild(label0)
div0.appendChild(input0)
form.appendChild(div1)
div1.appendChild(label1)
div1.appendChild(input1)
form.appendChild(div2)
div2.appendChild(label2)
div2.appendChild(input2)

//ordem


}

exercicio2()