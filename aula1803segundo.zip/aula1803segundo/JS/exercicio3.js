function exercicio3(){
const container = document.getElementById("container")

const card = document.createElement('div')
card.className = "card"

const img = document.createElement('img')
img.src ="../images/shoe.png"
img.alt ="Produto"

const titulo = document.createElement('h2')
titulo.textContent = "Tênis Esportivo"

const paragrafo = document.createElement('p')
paragrafo.textContent = "Comforto e estilo"

const span = document.createElement('span')
span.className = "preco"
span.textContent = "R$ 199,90"

const br = document.createElement('br')

const butao = document.createElement('button')
butao.textContent = "Comprar"

container.appendChild(card)
card.appendChild(img)
card.appendChild(titulo)
card.appendChild(paragrafo)
card.appendChild(span)
card.appendChild(br)
card.appendChild(butao)

}

exercicio3()