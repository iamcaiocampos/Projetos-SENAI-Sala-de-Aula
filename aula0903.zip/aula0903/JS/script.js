function Mensagem(){

   let mensagens = ["Não desista", "Você não está sozinho", "Você se pode viver uma vez"]
    
   let randomnumber = Math.floor(Math.random() * (2 - 0 + 1) + 0)

   console.log(randomnumber)


   document.getElementById("resultado").innerHTML = mensagens[randomnumber]

}