let numeros = [50, 100, 200]

let imposto = numeros.map(function(n){
    let temp = n * 1.10
    return temp.toFixed(0)
})

console.log(imposto)