let nomes = ["Caio", "Felipe", "Wallace", "Lucas", "Carlos"]

nomes.forEach(function(n){
    console.log(n)
})
