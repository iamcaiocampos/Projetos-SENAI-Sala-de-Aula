let numeros = [2, 4, 6, 8]

let dobrados = numeros.map(function(n){
    return n * 2
})

console.log(dobrados)