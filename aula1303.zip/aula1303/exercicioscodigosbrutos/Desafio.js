let alunos = [
    {nome: "Ana", nota: 8},
    {nome: "Carlos", nota: 6},
    {nome: "Maria", nota: 9}
    ]

alunos.forEach(function(n){
    if(n.nota >= 7){
        console.log(n.nome + "- Aprovado")
    } else{
        console.log(n.nome + "- Reprovado")
    }
})