let alunos = [
    {nome: "Ana", nota: 8},
    {nome: "Carlos", nota: 6},
    {nome: "Maria", nota: 9}
    ]


let statusalunos = alunos.map(function(n){
    if(n.nota >= 7){
       return n.nome + " - Aprovado"
    } else{
        return n.nome + " - Reprovado"
    }
})

console.log(statusalunos)

