let numeros = [2, 4, 6, 8, 10];

numeros.forEach(function(n){
    console.log(n * 2)
});
