let numeros = [3, 8, 12, 7, 10]

numeros.forEach(function(n){
    if(n % 2 == 0){
        console.log(n)

    }
})