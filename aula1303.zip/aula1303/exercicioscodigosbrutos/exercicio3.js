let numeros = [5, 10, 15, 20];
let soma = 0

numeros.forEach(function(n){
    soma = soma + n
    
});

console.log(soma)