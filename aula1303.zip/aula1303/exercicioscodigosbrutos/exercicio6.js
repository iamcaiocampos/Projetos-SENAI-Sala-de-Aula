let precos = [10, 25, 30, 5]

precos.forEach(function(pre){
     console.log("R$" + pre)
})