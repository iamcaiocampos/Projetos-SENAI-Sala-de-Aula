let nomes = ["ana", "carlos", "maria", "joão"]

let maisculos = nomes.map(function(name){
   return name.toUpperCase();
})

console.log(maisculos)