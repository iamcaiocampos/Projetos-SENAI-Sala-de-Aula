let frutas = ["Maça", "Banana", "Abacaxi", "Manga"]
let indice = 0

frutas.forEach(function(fr, ind){
    console.log(ind + "-" + fr)
})