let usuarios = [
    {nome: "Ana", idade: 20},
    {nome: "Carlos", idade: 25},
    {nome: "Maria", idade: 22}
    ]

let nomes = usuarios.map(function(usu){
    return usu.nome
})

console.log(nomes)