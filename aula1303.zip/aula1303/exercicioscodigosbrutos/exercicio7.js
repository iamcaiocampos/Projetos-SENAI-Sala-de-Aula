let cores = ["Amarelo", "Azul", "Vermelho", "Preto"]
let count = 0

cores.forEach(function(n){
   count++

})

console.log(cores)

console.log ("Existem " + count + " Elementos")