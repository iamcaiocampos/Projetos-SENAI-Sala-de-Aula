﻿// See https://aka.ms/new-console-template for more information

bool rep = true;
string nada;
while (rep)
{
    Console.Write("Quantos alunos e medias você quer cadastrar: ");
    bool foi = int.TryParse(Console.ReadLine(), out int quantia);
    string[] nomes = new string[quantia];
    double[] medias = new double[quantia];
    if (foi && quantia > 0)
    {
        for(int i = 0; i < quantia; i++)
        {
            Console.Write($"Qual o nome do {i+1} aluno: ");
            string nome = Console.ReadLine();
            Console.Write($"Qual o media do {i+1} aluno: ");
            foi = double.TryParse(Console.ReadLine(),out double notaMedia);
            nomes[i] = nome;
            medias[i] = notaMedia;

            if(!foi || medias[i] < 0)
            {
                Console.WriteLine("\nErro ao pegar o valor, por ser invalido, se quiser recomeçar e so clicar enter: ");
                 nada = Console.ReadLine();
                return;
            }
        }
    }
    else
    {
        Console.WriteLine("\nErro ao pegar o valor, por ser invalido, se quiser recomeçar e so clicar enter: ");
         nada = Console.ReadLine();
    }

    Console.WriteLine("\nAperte qualquer tecla para continuar");
     nada = Console.ReadLine() ;
    Console.Clear();
    for(int i = 0;i < nomes.Length;i++)
    {
        Console.WriteLine($"{i} - O aluno {nomes[i]} teve media {medias[i]}");
    }
}