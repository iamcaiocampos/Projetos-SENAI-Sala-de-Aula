﻿namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] alunos = { "Caio", "Felipe", "Wallace", "Nicolas", "Carlos", "Paula", "Lucas", "Lenaldo", "Logan", "Leandro" };

            string nome, resposta = "Nome não achado no index";
            Console.WriteLine("Coloque qual nome você quer pesquisar: ");
            nome = Console.ReadLine();

            for (int i = 0; i < alunos.Length; i++)
            {
                if (nome == alunos[i])
                {
                    Console.WriteLine("Este nome está no indice: " + i);
                    
                }
                


                
            }
            
           
        }
    }
}