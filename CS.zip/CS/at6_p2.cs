﻿bool rep = true, foi;
string nada = "";
int quantia_alunos_turma = 0;
while (rep)
{
    Console.WriteLine("Quantoa alunos você quer cadastrar: ");
    int quantiaAluno = int.Parse(Console.ReadLine());

    Console.WriteLine("Quantoa notas por aluno você quer cadastrar: ");
    int quantiaNotas = int.Parse(Console.ReadLine());

    double[,] notas = new double[quantiaAluno, quantiaNotas];
    double[] notas_do_aluno = new double[quantiaNotas];
    string[] alunos = new string[quantiaAluno];
    double[] media = new double[quantiaAluno];

    for (int i = 0; i < quantiaAluno; i++)
    {
        Console.Clear();
        Console.Write($"Digite o {i + 1} nome do aluno: ");
        alunos[i] = Console.ReadLine();

            for(int j = 0; j < quantiaNotas; j++)
            {
                Console.Write($"Digite a {i + 1} nota do aluno {alunos[i]}: ");
                foi = double.TryParse(Console.ReadLine(), out notas[i, j]);

                if (foi && notas[i, j] > 0 && notas[i, j] < 10)
                {
                continue;
                }
                else
                {
                    Console.WriteLine("Erro ao pegar a nota que continuar a pegar a nota(s ou n-você sai)");
                    string escolha = Console.ReadLine();
                    if (escolha == "s" || escolha == "S" || escolha == "Sim" || escolha == "sim")
                    {
                        i -= 1;
                        continue;
                    }
                    else
                    {
                        rep = false;
                        return;
                    }
                }
            }
    }

    for(int i =0; i< quantiaAluno; i++)
    {
        for(int j = 0; j< quantiaNotas; j++)
        {
            notas_do_aluno[j] = notas[i, j];
        }
        media[i] = Media(notas_do_aluno);
    }

    Console.WriteLine("Aperte enter para ir ver os alunos e suas notas");
    nada = Console.ReadLine();

    for(int i = 0; i< quantiaAluno; i++)
    {
        Console.WriteLine($"A media do aluno {alunos[i]} foi {media[i].ToString("f2")} ele esta {Status(media[i])}");
    }
    Console.WriteLine("\n\nSe quiser para digite n ou não se não so clique");
    nada = Console.ReadLine();
    if (nada == "n" || nada == "nao")
    {
        rep = false;
        return;
    }

}

static double Media(double[] notas)
{
    double media = notas.Sum() / notas.Length;
    return media;
}

static string Status(double media)
{
    string statusFinal = "";

    if(media >= 7)
    {
        statusFinal = "Aprovado";
    }
    else
    {
        statusFinal = "Reprovado";
    }

    return statusFinal;
}




