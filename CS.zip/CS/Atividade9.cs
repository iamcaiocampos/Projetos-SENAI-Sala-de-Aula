﻿using System.Data;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] nomeproduto = { "blank", "Iphone", "LapTop", "Placa de vídeo" };
            int[] estoqueproduto = { 0, 13, 15, 23 };
            int lugar;
            int stocknew;
            int escolha = 67;

            

            while (escolha != 3)
            {
                Console.WriteLine("Escolha o que você deseja: \n 1-Listar produtos \n 2-Atualizar Estoque \n 3-Sair");
                escolha = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (escolha) { 
                case 1:
                    for (int i = 1; i < nomeproduto.Length; i++)
                    {
                        Console.WriteLine(i + "º Produto: " + nomeproduto[i] + ", Estoque: " + estoqueproduto[i]);
                    }
                    Console.WriteLine("Aperte Enter para continuar");
                     string blank = Console.ReadLine();
                        Console.Clear();
                    break;
                case 2:
                    Console.WriteLine("Digite o numero do produto que você quer mudar.");
                    lugar = int.Parse(Console.ReadLine());
                    Console.WriteLine("Qual a quantidade nova de estoque? ");
                    stocknew = int.Parse(Console.ReadLine());

                    estoqueproduto[lugar] = stocknew;
                        Console.Clear();
                    break;
                case 3:
                    Console.WriteLine("Volte novamente!");
                    break;
                default:
                    Console.WriteLine("Comando invalido.");
                    
                    break;
                        
                }
            }
        }
    } }