﻿namespace PrometheusCAC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int idade;
            Console.WriteLine("Qual sua idade?");
            idade = int.Parse(Console.ReadLine());

            if (idade <= 7 & idade >= 5 ) {
                Console.WriteLine("A Sua faixa étaria é infantil");
            }
            else if (idade <= 17 & idade >= 12)
            {
                Console.WriteLine("A Sua faixa étaria é juvenil");
            }

            else if (idade >= 18)
            {
                Console.WriteLine("A Sua faixa étaria é adulta");
            }
            else
            {

                Console.WriteLine("Sem faixa étaria apropriada.");
            }
        }
    }
}