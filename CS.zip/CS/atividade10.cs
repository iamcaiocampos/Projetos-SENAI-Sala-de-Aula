﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int codigo = rnd.Next(0,10);
            string[] produtos = {"blank", "Arroz", "Queijo", "Leite"};
            int[] qtd = {0, 12, 152, 65 };
            string[] desc = { "blank", "Integral", "Mussarela", "Desnatado" };
            string[] data_vali = { "blank", "22/02/2026", "12/05/2026", "12/08/2026"};
            int opc = 0;

            while (opc != 0) {
                Console.WriteLine("Escolha o que você deseja fazer: \n 1-Exibir informações \n 2-Pesquisar nome do produto \n 3-Excluir produto \n 4-Atualizar quantidade de produtos cadastrados");
                 opc = int.Parse(Console.ReadLine());
            switch(opc)
                {
                   case 0:
                        Console.WriteLine("Volte novamente!");
                        break;
                    case 1:
                        for(int i = 0;)
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;


                }
            }
        }
    }
}