﻿using System.Linq.Expressions;

namespace ConsoleApp6
{
    internal class Program

    {
        static void Main(string[] args)
        {
            double total = 0;
            int[] num1 = new int[51];
            int escolha = 0;  

            Random rnd = new Random();

            for (int i = 1; i < 51; i++)
            {
                num1[i] = rnd.Next(0, 11);
                total = total + num1[i];
                Console.WriteLine("O " + i + "º é: " + num1[i]);

            }
            double media = total / 50;
            Console.WriteLine("A sua média é: " + media);

            if (media >= 6)
            {
                Console.WriteLine("Você está aprovado!");
            }
            if (media >= 2 & media < 6)
            {
                Console.WriteLine("Você está em recuperação!");
            }
            if (media < 2)
            {
                Console.WriteLine("Você está reprovado!");
            }
            
            Console.WriteLine("Qual nota em particular você deseja ver?");
            escolha = int.Parse(Console.ReadLine());

            Console.WriteLine("A nota de número " + escolha + " é " + num1[escolha]);
        }
    }
}
