﻿// See https://aka.ms/new-console-template for more information

bool rep = true;
string nada;
while (rep)
{
    Console.Write("Quantos produtos você quer cadastrar: ");
    bool foi = int.TryParse(Console.ReadLine(), out int quantia);
    string[] nomes = new string[quantia];
    double[] precos = new double[quantia];
    if (foi && quantia > 0)
    {
        for (int i = 0; i < quantia; i++)
        {
            Console.Write($"Qual o nome do {i + 1} produtos: ");
            string nome = Console.ReadLine();
            Console.Write($"Qual o valor do {i + 1} produtos: ");
            foi = double.TryParse(Console.ReadLine(), out double preco);
            nomes[i] = nome;
            precos[i] = preco;

            if (!foi || precos[i] < 0)
            {
                Console.WriteLine("\nErro ao pegar o valor, por ser invalido, se quiser recomeçar e so clicar enter: ");
                nada = Console.ReadLine();
                return;
            }
        }
    }
    else
    {
        Console.WriteLine("\nErro ao pegar o valor, por ser invalido, se quiser recomeçar e so clicar enter: ");
        nada = Console.ReadLine();
    }

    Console.WriteLine("\nAperte qualquer tecla para continuar e ver os precos modificados");
    nada = Console.ReadLine();
    Console.Clear();
    Console.WriteLine("Antigo \n");
    for (int i = 0; i < nomes.Length; i++)
    {
        Console.WriteLine($"{i} - O Produto {nomes[i]} tem preco {precos[i].ToString("f2")}");
    }
;
    for (int i = 0; i < nomes.Length; i++)
    {
        precos[i] = precos[i] * 1.1;
    }

    Console.WriteLine("\n\nAtual \n");
    for (int i = 0; i < nomes.Length; i++)
    {
        Console.WriteLine($"{i} - O Produto {nomes[i]} tem preco {precos[i].ToString("f2")}");
    }
}

