﻿bool rep = true, foi;
string nada = "";
double[] notas = new double[5];
while (rep)
{
    for(int i = 0; i < 5; i++)
    {
        Console.Clear();
        Console.Write($"Digite a {i + 1} nota do aluno: ");
        foi = double.TryParse(Console.ReadLine(), out notas[i]);

        if(foi && notas[i] > 0 && notas[i] < 10)
        {
            continue;
        }
        else
        {
            Console.WriteLine("Erro ao pegar a nota que continuar a pegar a nota(s ou n-você sai)");
            string escolha = Console.ReadLine();
            if(escolha == "s" || escolha == "S" || escolha == "Sim" || escolha == "sim")
            {
                i -= 1;
                continue;
            }
            else
            {
                rep = false;
                return;
            }
        }
    }

    Console.WriteLine($"A media do aluno foi {Media(notas)} \n\nSe quiser para digite n ou não se não so clique");
    nada = Console.ReadLine();
    if(nada == "n" || nada == "nao")
    {
        rep = false;
        return;
    }

}

static double Media(double[] notas)
{
    double media = notas.Sum()/notas.Length;
    return media;
}