async function ExibirDados(){

    const response = await fetch("../json/dados.json");
    const jsonDados = await response.json();
    let dados = document.getElementById("dados")

    jsonDados.forEach(element => {
    dados.innerHTML += 
    `<br><br>Nome: ${element.nome}<br>
    Idade: ${element.idade}<br>
    Profissão: ${element.profissao}<br>
    Cidade: ${element.cidade}`

    });
}