let hum = document.getElementById("humidade");
let tem = document.getElementById("temperatura");
let luz = document.getElementById("qtdluz");

// Atualiza humidade
function receberhumidade(valor) {
    hum.innerHTML = `Humidade: ${valor}%`;
}

// Atualiza temperatura
function recebertemperatura(valor) {
    tem.innerHTML = `Temperatura: ${valor}°C`;
}

// Atualiza luz
function receberqtdluz(valor) {
    luz.innerHTML = `Nível de luz: ${valor}`;
}

// Busca dados do servidor Node
async function pegarDados() {

    try {

        const resposta = await fetch("http://localhost:3000/pegarDados");

        const dados = await resposta.json();

        if (dados.humidade !== undefined) {
            receberhumidade(dados.humidade);
        }

        if (dados.temperatura !== undefined) {
            recebertemperatura(dados.temperatura);
        }

        if (dados.luz !== undefined) {
            receberqtdluz(dados.luz);
        }

    } catch (erro) {

        console.log("Erro ao buscar dados:", erro);

    }

}

// Atualiza automaticamente
setInterval(pegarDados, 2000);

// Executa ao abrir
pegarDados();