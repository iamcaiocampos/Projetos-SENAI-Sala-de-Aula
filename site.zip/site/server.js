import express from 'express';
import cors from 'cors';

const app = express();

let ultimosDados = {};

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Recebe dados da ESP
app.post('/recebeDados', (req, res) => {

    const dadosVindos = req.body;

    if (dadosVindos != null) {
        ultimosDados = dadosVindos;
    }

    console.log("Dados recebidos:", dadosVindos);

    res.status(200).json({
        mensagem: "Dados recebidos com sucesso"
    });

});

// Envia dados para o site
app.get('/pegarDados', (req, res) => {

    res.json(ultimosDados);

});

app.listen(3000, () => {
    console.log("Servidor inicializado na porta 3000");
});