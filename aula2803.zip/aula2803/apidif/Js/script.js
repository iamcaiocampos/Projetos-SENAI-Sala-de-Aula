async function dolar(){
    let display = document.getElementById("valores")

    let response = await fetch("https://economia.awesomeapi.com.br/json/last/USD-BRL")

    let dados = await response.json()

    let usd = dados.USDBRL

    console.log(dados)

    display.innerHTML = `Valor do Dólar no dia e horário ${usd.create_date}: <br><br>${usd.high}R$`

}

async function pais(){
     let display = document.getElementById("valores")

     let pais = document.getElementById("pais").value

    let response = await fetch(`https://restcountries.com/v3.1/name/${pais}`)

    let dados = await response.json()

    console.log(dados)

    display.innerHTML = `Nome: ${dados[0].population}<br>
                         Capital: ${dados[0].capital}<br>
                         Horário: ${dados[0].timezones} `


}

async function cao(){
    let display = document.getElementById("valores")
     
    let response = await fetch(`https://dog.ceo/api/breeds/image/random`)

    let dados = await response.json()

    display.innerHTML = `<img src = "${dados.message}">`

}