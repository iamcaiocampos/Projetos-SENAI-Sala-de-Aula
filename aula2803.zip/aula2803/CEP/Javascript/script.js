async function Buscar(){
    let cep = document.getElementById("CEP").value
    let logradouro = document.getElementById("log")
    let display = document.getElementById("display")
    console.log(cep)

    

    const response = await fetch(`https://opencep.com/v1/${cep}`)

    const dados = await response.json()

    logradouro.value = dados.logradouro;

    display.innerHTML = `<p>Complemento: ${dados.complemento}<br>
                         Unidade: ${dados.unidade}<br>
                         bairro: ${dados.bairro}<br>
                         localidade: ${dados.localidade}<br>
                         uf: ${dados.uf}<br>
                         ibge: ${dados.ibge}<br></p>`
                         

    log.innerHTML = logradouro
    
    console.log(dados.ibge)

    console.log(dados)



    
    
   

}

