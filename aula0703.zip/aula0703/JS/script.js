function CalculoIMC(){
    let peso = document.getElementById("peso").value;
    let altura = document.getElementById("altura").value;

peso = parseFloat(peso);
altura = parseFloat(altura);

let imc = peso / (altura * altura);

if(imc < 18.5){
  document.getElementById("resultado").innerHTML =
        "Seu IMC é: " + imc.toFixed(2) + ", Você está abaixo do peso.";
}

if(imc >= 18.5 & imc <25){
  document.getElementById("resultado").innerHTML =
        "Seu IMC é: " + imc.toFixed(2) + ", Você está com o peso normal.";
}

if(imc >= 25 & imc <30){
  document.getElementById("resultado").innerHTML =
        "Seu IMC é: " + imc.toFixed(2) + ", Você está com sobrepeso.";
}

if(imc > 30){
  document.getElementById("resultado").innerHTML =
        "Seu IMC é: " + imc.toFixed(2) + ", Você está com obesidade.";
}

}
