let produtos = ["Farinha", "Arroz", "Macarrão"]



function Inserir() {
    let item = document.getElementById('textbox').value

    produtos.push(item)

    console.log(produtos)
}

function Exibir() {

    let lista = document.getElementById("lista");


    for (let i = 0; i < produtos.length; i++) {
        lista.innerHTML += `<li>${produtos[i]} </li>`
    }


}

function Pesquisar() {
    let foi = false
    let pesquisa = document.getElementById("textbox").value
    console.log(produtos)
    let lista = document.getElementById("lista")


    for (let i = 0; i < produtos.length; i++) {
        console.log(i)
        if (produtos[i].toLowerCase() == pesquisa.toLowerCase()) {
            lista.innerHTML = `<li> ${produtos[i]}</li>`
            alert("Produto encontrado")
            foi = true
            
        } 

    }

    if(foi == false){
        alert("Produto não encontrado")
    }

}

function Atualizar() {

}