function exibirValores(){
    const contain = document.getElementById("container");

    const container_card = document.createElement('div')
    container_card.className = "container_card"

    const container_imagem = document.createElement('div')
    container_imagem.className = "container_imagem"

    const titulo = document.createElement('h1')
    titulo.textContent = "Baleias"



    const nome = document.createElement('h2')
    nome.textContent = "Cachalote"

    const texto = document.createElement('p')
    texto.id = "textoimagem";
    const imagem = document.createElement('img')
    texto.textContent = "Cachalote ou cacharréu (nome científico: Physeter macrocephalus)[3][4] é o maior cetáceo dentado (odontocetos) e o maior predador com dentes. É o único membro vivo do gênero Physeter e uma das três espécies existentes na superfamília Physeteroidea, juntamente com o cachalote-pigmeu e o cachalote-anão do Kogia. É um mamífero pelágico com distribuição mundial e migra sazonalmente para alimentação e reprodução.[5] As fêmeas e os machos jovens vivem juntos em grupos, enquanto os machos maduros vivem vidas solitárias fora da época de acasalamento. As fêmeas cooperam para proteger e amamentar seus filhotes. As fêmeas dão à luz a cada quatro a vinte anos e cuidam dos bezerros por mais de uma década. Um cachalote maduro tem poucos predadores naturais, embora bezerros e adultos enfraquecidos às vezes sejam mortos por grupos de orcas (Orcinus orca). "
   imagem.src = "../IMG/cachalote.jpg"

   container_imagem.appendChild(titulo)
    container_imagem.appendChild(nome)
    container_imagem.appendChild(imagem)
    container_imagem.appendChild(texto)
      

    const nome2 = document.createElement('h2')
    nome2.textContent = "Orca"

    imagem.className = "imagem1"

    const container_imagem2 = document.createElement('div')
    container_imagem2.className = "container_imagem"
    
    const texto2 = document.createElement('p')
    texto2.id = "textoimagem";
    const imagem2 = document.createElement('img')
    texto2.textContent = "A orca (Orcinus orca), também conhecida como baleia-assassina, é um cetáceo odontoceto (baleia com dentes) e o maior membro da família dos golfinhos oceânicos. É a única espécie existente do gênero Orcinus e é facilmente reconhecida pela sua coloração característica em preto e branco. Trata-se de uma espécie cosmopolita, que habita uma grande variedade de ambientes marinhos, desde regiões do Ártico e Antártico até mares tropicais. "
   imagem2.src = "../IMG/orca.avif"
    container_imagem2.appendChild(imagem2)
    container_imagem2.appendChild(texto2)
    container_imagem.appendChild(nome2)

    imagem2.className = "imagem2"


    const container_imagem3 = document.createElement('div')
    container_imagem3.className = "container_imagem"

    const nome3 = document.createElement('h2')
    nome3.textContent = "Jubarte"
    
    const texto3 = document.createElement('p')
    texto3.id = "textoimagem";
    const imagem3 = document.createElement('img')
    texto3.textContent = "A jubarte ou baleia-jubarte (nome científico: Megaptera novaeangliae), também conhecida como baleia-corcunda, baleia-cantora,[2] baleia-corcova, baleia-de-corcova, baleia-de-bossas, baleia-preta[3] ou baleia-xibarte[4] é um mamífero marinho presente na maioria dos oceanos.[5] Ela é da ordem dos cetartiodáctilos (Cetartiodactyla), subordem dos cetáceos e infraordem dos misticetos (Mysticeti)."
   imagem3.src = "../IMG/humpbackwhale.webp"
   container_imagem3.appendChild(nome3)
    container_imagem3.appendChild(imagem3)
    container_imagem3.appendChild(texto3)
    
    

    imagem3.className = "imagem3"

    const container_imagem4 = document.createElement('div')
    container_imagem4.className = "container_imagem"

    const nome4 = document.createElement('h2')
    nome4.textContent = "Narval"

    const texto4 = document.createElement('p')
    texto4.id = "textoimagem";
    const imagem4 = document.createElement('img')
    texto4.textContent = "O narval[5] ou unicórnio-do-mar[6] é um cetáceo odontoceto de tamanho médio e o animal com os maiores caninos. Vive durante todo o ano no Ártico. É uma das duas espécies vivas de baleias da família Monodontidae, juntamente com a beluga e o Golfinho-do-irauádi. Os narvais machos são distinguidos por uma presa helicoidal longa e reta que, na verdade, é um canino superior esquerdo alongado. Vale ressaltar que aproximadamente 15% das fêmeas também desenvolvem essa presa. Encontrados principalmente no Norte do Canadá e águas da Gronelândia, raramente ao sul de 65° N de latitude, os narvais são predadores do ártico excepcionalmente especializados. "
   imagem4.src = "../IMG/narwhal.webp"
   container_imagem4.appendChild(nome4)
    container_imagem4.appendChild(imagem4)
    container_imagem4.appendChild(texto4)

    imagem4.className = "imagem4"
    

    container_card.appendChild(container_imagem)
    container_card.appendChild(container_imagem2)
    container_card.appendChild(container_imagem3)
    container_card.appendChild(container_imagem4)
    contain.appendChild(container_card)
}

exibirValores()
