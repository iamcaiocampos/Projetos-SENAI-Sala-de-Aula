function matematica(){
let valor1 = document.getElementById("valor1")
let valor2 = document.getElementById("valor2")

let resultado = valor1 + valor2
}